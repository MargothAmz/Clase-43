class Form {
  constructor() {
    this.greetings = createElement("h2");
    this.input = createInput("NOMBRE");
    this.buttonImg = createImg("./images/start.png");
  }
  display() {
   this.input.position(380, 180);
    this.input.size(180, 30);
    this.buttonImg.position(395,270);
    this.buttonImg.size(160, 70);
    
  }
  
}

