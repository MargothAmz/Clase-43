class Player {
  constructor() {
   
  }

}
